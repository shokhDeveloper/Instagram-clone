/**
 * Is this my tail?
 * https://www.codewars.com/kata/is-this-my-tail/
 */
