/**
 * Use map() to double the values in an array
 * https://www.codewars.com/kata/use-map-to-double-the-values-in-an-array
 */
