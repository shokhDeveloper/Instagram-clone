/**
 * Hello Happy Codevarrior!
 * https://www.codewars.com/kata/hello-happy-codevarrior
 */
