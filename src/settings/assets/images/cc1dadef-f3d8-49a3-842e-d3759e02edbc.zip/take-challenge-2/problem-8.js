/**
 * Custom each() Array method
 * http://www.codewars.com/kata/custom-each-array-method
 */
