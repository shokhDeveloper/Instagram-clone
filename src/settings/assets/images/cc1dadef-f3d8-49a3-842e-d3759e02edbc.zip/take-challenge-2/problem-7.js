/**
 * Tea for two
 * http://www.codewars.com/kata/tea-for-two
 */
