/**
 * Josephus survivor
 * http://www.codewars.com/kata/josephus-survivor
 */
