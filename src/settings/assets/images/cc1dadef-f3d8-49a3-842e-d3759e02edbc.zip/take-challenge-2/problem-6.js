/**
 * Javascript filter - 3
 * http://www.codewars.com/kata/javascript-filter-3/train/javascript
 */
