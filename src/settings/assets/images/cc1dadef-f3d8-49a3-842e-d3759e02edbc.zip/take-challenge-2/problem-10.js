/**
 * Color Ghost
 * http://www.codewars.com/kata/color-ghost
 */
