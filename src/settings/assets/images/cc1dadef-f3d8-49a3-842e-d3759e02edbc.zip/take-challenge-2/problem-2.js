/**
 * Javascript filter - 2
 * https://www.codewars.com/kata/javascript-filter-2/train/javascript
 */
