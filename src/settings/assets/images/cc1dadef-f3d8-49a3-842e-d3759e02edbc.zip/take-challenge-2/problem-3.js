/**
 * Ninja vs Samurai: Attack + Block
 * https://www.codewars.com/kata/ninja-vs-samurai-attack-plus-block
 */
