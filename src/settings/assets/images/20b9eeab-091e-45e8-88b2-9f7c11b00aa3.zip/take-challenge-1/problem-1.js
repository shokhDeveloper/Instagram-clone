/**
 * How good are you really?
 * https://www.codewars.com/kata/how-good-are-you-really
 */
