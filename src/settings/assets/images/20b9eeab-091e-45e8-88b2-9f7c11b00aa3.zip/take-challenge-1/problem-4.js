/**
 * Directions Reduction
 * https://www.codewars.com/kata/directions-reduction
 */
