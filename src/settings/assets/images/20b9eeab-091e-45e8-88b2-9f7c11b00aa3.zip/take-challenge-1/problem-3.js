/**
 * Your order, please
 * https://www.codewars.com/kata/your-order-please
 */
