/**
 * Katastrophe!
 * https://www.codewars.com/kata/katastrophe
 */


