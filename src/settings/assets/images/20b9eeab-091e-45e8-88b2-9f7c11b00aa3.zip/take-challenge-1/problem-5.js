/**
 * Powers of 2
 * https://www.codewars.com/kata/powers-of-2
 */
