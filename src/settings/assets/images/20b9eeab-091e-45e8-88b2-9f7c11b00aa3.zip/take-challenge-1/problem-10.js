/**
 * Don't Drink the Water
 * https://www.codewars.com/kata/dont-drink-the-water
 */
