/**
 * Number Zoo Patrol
 * https://www.codewars.com/kata/number-zoo-patrol
 */
