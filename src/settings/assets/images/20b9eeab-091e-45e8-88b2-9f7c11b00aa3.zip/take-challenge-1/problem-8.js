/**
 * Javascript filter - 1
 * https://www.codewars.com/kata/javascript-filter-1/train/javascript
 */
