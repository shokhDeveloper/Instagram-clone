/**
 * Is my friend cheating?
 * https://www.codewars.com/kata/is-my-friend-cheating
 */
