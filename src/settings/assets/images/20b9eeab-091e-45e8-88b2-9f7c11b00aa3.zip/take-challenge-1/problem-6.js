/**
 * Mumbling
 * https://www.codewars.com/kata/mumbling
 */
